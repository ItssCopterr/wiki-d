links to all connected wiki'd articles.
all data was provided by Wikipedia.
[[Computer]]
[[Book]]
[[Real Estate]]
[[Government]]
[[Country]]